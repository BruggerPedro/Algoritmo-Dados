#include <stddef.h>
#include<stdlib.h>
#include "ListaFloat.h"

struct no{
	float info; //N�mero
	struct no *prox; // Por ser dinamico, agora temos um ponteiro que "aponta" ao proximo n�
};


//_______________________________________________________________________________________________________________

/*
Opera��o: cria_lista
- Entrada: Sem entrada.
  Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Cria uma lista e retorna o endere�o de uma lista apontando pra NULL.
- Sa�da: NULL
- P�s-condi��o: Sem p�s-condi��o.
*/

Lista cria_lista(){
return NULL;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: lista_vazia;
- Entrada: Endere�o de uma lista.
- Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Verifica se a lista est� vazia.
- Sa�da: 0 (Lista n�o est� vazia), 1 (Lista vazia)
- P�s-condi��o: Sem p�s-condi��o.
*/

int lista_vazia(Lista lst){
    if(lst == NULL)
        return 1; //Lista vazia
    else
        return 0; //Lista aponta pra algo, logo, n�o � vazia
}

// _______________________________________________________________________________________________________________

/* Na teoria, n�o existe como "encher" uma lista dinamica, [exceto pela limita��o de espa�o na memoria])*/


//int lista_cheia(Lista *li){
//return 0;
//}
// _______________________________________________________________________________________________________________

/*
Opera��o: insere_elem;
- Entrada: Endere�o do endere�o de uma lista e o elemento (float) a ser inserido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um float.
- Processo: Insere (de forma n�o ordenada) o elemento na lista fornecida.
- Sa�da: 0 (Lista n�o existe), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista de forma n�o ordenada.
*/


int insere_elem(Lista *lst, float elem){
    // Aloca um novo n�
    Lista N = (Lista) malloc(sizeof(struct no)); // N aloca um novo campo de lista
    if (N == NULL) //Falha: N�o conseguiu alocar o N�
        {
            return 0;
        }
    N->info = elem; //Insere o conteudo (valor de elem)
    N->prox = *lst; //Aponta para o 1� n� atual da lista
    *lst = N;       // Faz a lista apontar para o novo n�
    return 1;       // Inserido
}

// _______________________________________________________________________________________________________________


/*
Opera��o: remove_elem;
- Entrada: Endere�o do endere�o de uma lista e o elemento (float) a ser removido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um float.
- Processo: Remove o elemento na lista fornecida.
- Sa�da: 0 (Lista vazia ou elemento n�o presente na lista), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/

int remove_elem(Lista *lst, float elem){
    if(lista_vazia(*lst) == 1) //Se lista estiver vazia
        return 0; //Falha
    Lista aux = *lst; //Ponteiro auxiliar para o 1� n�
    // Trata elemento = primeiro N� da lista
    if(elem == (*lst)->info){
        *lst = aux->prox; //Lista aponta para o segundo n�
        free(aux); // libera mem�ria alocada
        return 1; //  Sucesso
    }
    // Percorrimento at� achar o elem ou final da lista
    while(aux->prox != NULL && aux->prox->info != elem) //Enquanto existir proximo E info do proximo for diferente do elemento
        aux = aux->prox; // seguimos apontando ao proximo da lista
    if(aux->prox == NULL) //Trata final da lista
        return 0; //Falha
    //Remove elemento != do 1� n� da lista
    Lista aux2 = aux -> prox; // Aponta n� a ser removido
    aux->prox = aux2->prox; // retira n� da lista
    free(aux2); //Libera mem�ria alocada
    return 1;
}

// _______________________________________________________________________________________________________________

// _______________________________________________________________________________________________________________

/*
Opera��o: esvazia_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: Lista existir (Endere�o ser valido)
- Processo: Esvaziar a lista.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: a instancia da lista no estado de vazia
*/

int esvazia_lista(Lista *lst){

    if(lst == NULL) { // Se o ponteiro estiver apontando NULL, a lista est� vazia
      return 0;
      }

    Lista aux = *lst; //Ponteiro auxiliar aponta para o come�o da lista

    while(*lst != NULL){ //Enquanto ponteiro for != de NULL
        (*lst) = (*lst)->prox; //Ponteiro atual recebe o proximo n�
        free(aux);  //Libera o n� atual
        aux = *lst; // aux aponta pra n� atual
    }
    free(aux); //Nessa regi�o, lst aponta pra null, ent�o, vamos liberar o aux

    return 1; // Sucesso

}

// _______________________________________________________________________________________________________________

/*
Opera��o: apaga_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: endere�o ser v�lido (primeiro endere�o �ponteiro de ponteiro�)
- Processo: liberar a instancia da lista e apagar o seu endere�o
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: instancia da lista liberada.
*/
void apaga_lista(Lista *lst){

    if(lst != NULL){ //Se for igual a null, a lista j� est� excluida

        Lista aux = *lst; // Aux aponta pra inicio da lista

        while(*lst != NULL){ // Enquanto existir n�
            (*lst) = (*lst)->prox; //lst aponta para o proximo n�
            free(aux); // Liberamos o n� atual
            aux = *lst; // Aux aponta para o mesmo n� de lst
        }
        free(aux); // Liberamos o aux
        free(lst); // Liberamos o lst
        //OBS: A diferen�a entre apaga e esvazia est� na linha acima.
        // Enquanto no esvazia "liberamos" apenas o aux, no apaga,
        // liberamos tambem o lst (responsavel por apontar a primeira posi��o na lista)
    }
}

// _______________________________________________________________________________________________________________

/*
Opera��o: get_elem_pos
- Entrada: Endere�o de uma lista, posi��o a obter o elemento e uma variavel para receber a informa��o da dita posi��o.
-  Pr�-Condi��o: Lista existir (Endere�o ser valido), a lista n�o estar vazia e posi��o ser maior que 0.
- Processo: Atrav�s da posi��o fornecida, busca-se na lista o elemento correspondente aquela posi��o e o retorna atraves da variavel fornecida.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: A variavel recebe o valor do elemento presente na posi��o fornecida.
*/

int get_elem_pos(Lista lst, int pos, float *elem){

    if(lst == NULL || lista_vazia(lst) || pos < 0)
        // lst aponta pra null? OU lista � vazia? OU pos <=0 OU pos > proximo?
     return 0; // FALHA

    *elem = lst->info; // elem recebe aquela informa��o do n� atual
    return 1; //Sucesso
}


// _______________________________________________________________________________________________________________

// Opera��es especiais:
// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________

/*
Opera��o: tamanho_lista
- Entrada: Endere�o do endere�o de uma lista e uma variavel para receber o tamanho da lista.
- Pr�-Condi��o: Lista existir (Endere�o ser valido).
- Processo: Percorre toda a lista e contabiliza o tamanho da mesma.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: A lista foi contabilizada e seu tamanho foi atribuido para a variavel vinda de argumento.*/

int tamanho_lista(Lista *lst, int *tam){

    if(lst == NULL) {// Se o ponteiro estiver apontando NULL, a lista est� vazia
      return 0;
        }

    int contador = 0; // Variavel contadora

    if(lista_vazia(*lst) == 1){ // Se lista estiver vazia
        *tam = contador; //Basta atribuir ao tam o valor que est� em contador(0)
        return 1;
    }


    Lista aux = *lst; // Aux aponta pra inicio da lista

    while(aux->prox != NULL){ // Enquanto "existir" proximo
        contador++;
        aux = aux->prox;
    }

    *tam = contador + 1; //Como o aux verifica uma posi��o "a frente" do n�, somamos o contador com +1 (N� atual que n�o possui prox n�)

    return 1;

}

// _______________________________________________________________________________________________________________

/*

Opera��o: remove_menor
- Entrada:  Endere�o do endere�o de uma lista e uma variavel para receber o menor elemento da lista.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e lista n�o ser vazia.
- Processo: Percorre toda a lista e remove o menor valor da lista.
- Sa�da: 1 (sucesso) ou 0 (falha).
- P�s-condi��o: A lista agora n�o prov�m do menor valor verificado.*/


int remove_menor(Lista *lst, float *menor){
    // Se lst aponta pra null OU lista vazia, retornamos 0
    if(lst == NULL || lista_vazia(*lst) == 1)
        return 0;


    *menor = (*lst)->info; // Come�amos dizendo que o primeiro n� � o menor

    int operem; // receber� a resposta da opera��o remove_elem
    float menornum = *menor; // Variavel local que armazena o menor valor

    if((*lst)->prox == NULL){// Se a lista tiver apenas um elemento
     operem = remove_elem(lst,menornum); // Chamamos a fun��o j� criada remove_elem passando a lista e o menor valor (obtido agora pela fun��o)
        if (operem == 0){ // Se a opera��o remover tiver falha
        return -1;     // Retornaremos -1 que significa, conseguimos encontrar o menor valor, MAS, n�o conseguimos remove-l�
        }else{
         return 1; // Retornaremos sucesso na fun��o remove_menor
    }
    }


    // Lista com + de 1 elemento:

    Lista aux = *lst; //aux aponta pro primeiro n�

    while(aux->prox != NULL){ // Enquanto existir proximo n�

        if(aux->info < (*menor)) //Se o info do n� for menor do j� armazenado na variavel menor
        *menor = aux->info; // Variavel menor � atualizada com o info do n�

        aux = aux->prox;   // Aux avan�a na lista
    }

    if(aux->info < (*menor)) //VERIFICANDO A ULTIMA POSICAO
    *menor = aux->info; // Variavel menor � atualizada com o info do n�



    menornum = *menor; // Variavel local que armazena o menor valor
    operem = remove_elem(lst,menornum); // Chamamos a fun��o j� criada remove_elem passando a lista e o menor valor (obtido agora pela fun��o)



    if (operem == 0){ // Se a opera��o remover tiver falha
        return -1;     // Retornaremos -1 que significa, conseguimos encontrar o menor valor, MAS, n�o conseguimos remove-l�
    }else{
         return 1; // Retornaremos sucesso na fun��o remove_menor
    }
}


// _______________________________________________________________________________________________________________

/*
Opera��o: listas_iguais
- Entrada: Endere�o do endere�o de duas listas a serem intercaladas.
- Pr�-Condi��o: Listas existirem (Endere�o ser valido).
- Processo: Recebe duas listas ordenadas e verifica se elas s�o iguais.
- Sa�da: -1 (Caso uma das listas n�o existirem), 0 (Se s�o diferentes), 1 (Se s�o iguais).
- P�s-condi��o: Sem p�s-condi��o.*/

int listas_iguais(Lista *l1, Lista *l2){

    if(l1 == NULL || l2 == NULL) {// Se o ponteiro estiver apontando NULL, uma das listas est� vazia
      return -1; // Excepcionalmente, o erro de ponteiro nulo ser� retorno -1.
    }

    int t1,t2; //Variaveis responsaveis por armazenar o tamanho das listas.

    // Obtendo o tamanho das listas e atribuindo-as para t1 e t2
    tamanho_lista(l1,&t1);
    tamanho_lista(l2,&t2);


    // RETORNO 0 == LISTAS DIFERENTES /  RETORNO == 1 LISTAS IGUAIS

    if(t1 != t2){ // Se de cara, as listas tiverem tamanho diferentes
        return 0; // Listas diferentes
    }

    Lista aux1 = *l1; // Aux1 aponta pra inicio da lista l1
    Lista aux2 = *l2; // Aux2 aponta pra inicio da lista l2



    // Como sabemos que o tamanho das duas listas s�o iguais, vamos usar qualquer uma delas de parametro para o for

    while (aux1 != NULL){
     if(aux1->info != aux2->info) // Se infos forem diferentes
     {
        free(aux1); // Liberamos o aux1
        free(aux2); // Liberamos o aux2
        return 0; // Listas diferentes
     }
        aux1 = aux1->prox;   // Aux1 avan�a na lista
        aux2 = aux2->prox;   // Aux1 avan�a na lista

    }

    // Se chegou aqui, � pq as listas s�o iguais.
        free(aux1); // Liberamos o aux1
        free(aux2); // Liberamos o aux2
    return 1; // Listas iguais

}

// _______________________________________________________________________________________________________________

/*
Opera��o: intercala_listas
- Entrada: Endere�o do endere�o de duas listas a serem intercaladas.
- Pr�-Condi��o: Listas existirem (Endere�o ser valido).
- Processo: Recebe duas listas e retorna uma terceira, formada pelos elementos das duas listas intercalados (Sem altera��o nas duas listas).
- Sa�da: NULL(Caso alguma das listas fornecidas n�o existe) ou ponteiro que referencia o local onde foi criada a terceira lista.
- P�s-condi��o: Sem p�s-condi��o.*/

Lista intercala_listas(Lista *l1, Lista *l2){

if(l1 == NULL || l2 == NULL) {// Se o ponteiro estiver apontando NULL, uma das listas est� vazia
      return NULL; // Excepcionalmente, o erro de ponteiro nulo.
    }

    int t1,t2; //Variaveis responsaveis por armazenar o tamanho das listas.
    int tamt; // Variavel responsavel pela soma dos "tamanhos" das duas listas

    // Obtendo o tamanho das listas e atribuindo-as para t1 e t2
    tamanho_lista(l1,&t1);
    tamanho_lista(l2,&t2);


    tamt = t1+t2; // Soma do tamanho das duas listas

    Lista l3  = cria_lista(); // Criamos a terceira lista

    int i; // Variavel contadora do for:

    Lista aux1 = *l1; // Aux1 aponta pra inicio da lista l1

    Lista aux2 = *l2; // Aux2 aponta pra inicio da lista l2


    int info; // Responsavel por receber o valor do n�(info)


    for(i=0;i<tamt;i++){
        if(i%2 == 0 && aux1 != NULL && t1>0){ // Se i for par e Diferente de NULL:
            info = aux1->info; // Atribui pra local info, o valor presente no n�
            insere_elem(&l3,info); // Chama fun��o insere passando a lista 3 e o valor info
            aux1 = aux1->prox;   // Aux1 avan�a na lista
            t1--; //Decrementa t1

        }else
        if (i%2 != 0 && aux2 != NULL && t2>0){ // Se i for impar e Diferente de NULL:
            info = aux2->info; // Atribui pra local info, o valor presente no n�
            insere_elem(&l3,info);// Chama fun��o insere passando a lista 3 e o valor info
            aux2 = aux2->prox;   // Aux2 avan�a na lista
            t2--; //Decrementa t2
        }else
        if (t1>0){ // Caso o tamanho das listas sejam diferentes, esse if garante preencher os elementos sobressalentes de l1
            info = aux1->info; // Atribui pra local info, o valor presente no n�
            insere_elem(&l3,info); // Chama fun��o insere passando a lista 3 e o valor info
            aux1 = aux1->prox;   // Aux1 avan�a na lista
            t1--; //Decrementa t1
        }else
        if(t2>0){ // Caso o tamanho das listas sejam diferentes, esse if garante preencher os elementos sobressalentes de l2
            info = aux2->info; // Atribui pra local info, o valor presente no n�
            insere_elem(&l3,info);// Chama fun��o insere passando a lista 3 e o valor info
            aux2 = aux2->prox;   // Aux2 avan�a na lista
            t2--; //Decrementa t2
        }
    }
        free(aux1); // Liberamos o aux1
        free(aux2); // Liberamos o aux2

    return l3; // Retorna a lista criada

}

// _______________________________________________________________________________________________________________

/*
Opera��o: libera
- Entrada: Endere�o de uma lista
- Pr�-Condi��o: Lista existir (Endere�o ser valido)
- Processo: Retira a aloca��o (Libera) de uma determinada lista.
- Sa�da: Sem saida (VOID).
- P�s-condi��o: A lista foi �liberada� da memoria.
*/

void libera(Lista x){

    if(x != NULL){
        free(x);
        x = NULL;
    }
}
