#include <stddef.h>
#include <stdlib.h>
#include "ListaCiclo.h"

struct no{
    char info; // letra
    struct no * prox; // Por ser dinamico, agora temos um ponteiro que "aponta" ao proximo n�
};

//_______________________________________________________________________________________________________________

/*
Opera��o: cria_lista
- Entrada: Sem entrada.
  Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Cria uma lista e retorna o endere�o de uma lista apontando pra NULL.
- Sa�da: NULL
- P�s-condi��o: Sem p�s-condi��o.
*/

Lista cria_lista() {
    return NULL;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: lista_vazia;
- Entrada: Endere�o de uma lista.
- Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Verifica se a lista est� vazia.
- Sa�da: 0 (Lista n�o est� vazia), 1 (Lista vazia)
- P�s-condi��o: Sem p�s-condi��o.
*/

int lista_vazia (Lista lst) {
    if (lst == NULL)  {
        return 1;
    }
    else {
         return 0;
    }
}

// _______________________________________________________________________________________________________________

/* Na teoria, n�o existe como "encher" uma lista dinamica, [exceto pela limita��o de espa�o na memoria])*/


//int lista_cheia(Lista *li){
//return 0;
//}
// _______________________________________________________________________________________________________________

/*
Opera��o: insere_final;
- Entrada: Endere�o do endere�o de uma lista e o elemento (char) a ser inserido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um char.
- Processo: Insere (ao final) o elemento na lista fornecida.
- Sa�da: 0 (Lista n�o existe), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista.
*/


int insere_final(Lista *lst, char elem){
// Alocar um novo n� e preencher campo info
Lista N = (Lista) malloc(sizeof(struct no));
if (N==NULL){ return 0; } //Falha na aloca��o do n�

N->info = elem; // Insere o conteudo

// Se lista vazia:
 if(lista_vazia(*lst) == 1){
    N->prox = N; //Faz o novo n� apontar pra ele msm
    *lst = N; //Lista apontar� para o novo n�(�ltimo n�)
 }

 // Caso j� exista elementos na lista:
 else{
    N->prox = (*lst)->prox; //Novo n� apontar� para o primeiro n� (come�o)
    (*lst)->prox = N; //Faz o ultimo n� apontar para o novo n�
    *lst = N; //Lista aponta para o novo n� (Ultima posi��o)
 }
 return 1;
}

// _______________________________________________________________________________________________________________


/*
Opera��o: remove_inicio;
- Entrada: Endere�o do endere�o de uma lista e uma variavel para receber o valor excluido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um char.
- Processo: Remove o primeiro n�.
- Sa�da: 0 (Lista vazia ou elemento n�o presente na lista), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/

int remove_inicio(Lista *lst, char *elem){

// Se lista estiver vazia:
if (lista_vazia(*lst) == 1)
    return 0; // Falha


Lista aux = (*lst)->prox; //Faz aux apontar para o 1� n�
*elem = aux->info; //Retorna valor do n� a ser removido

if(*lst == (*lst)->prox) //Se a lista tiver apenas um elemento
    *lst = NULL; //Fazemos a lista apontar pra nada (J� que excluiremos o unico n�)

else // Trata lista + de 1 elemento
    (*lst)->prox = aux -> prox; //Lista aponta para o "segundo" elemento
    free(aux); //Libera o primeiro elemento
return 1; //Sucesso


}

// _______________________________________________________________________________________________________________

/*
Opera��o: esvazia_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: Lista existir (Endere�o ser valido)
- Processo: Esvaziar a lista.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: a instancia da lista no estado de vazia
*/

int esvazia_lista(Lista *lst){
    if((*lst) == NULL){ // Se o ponteiro estiver apontando NULL, a lista est� vazia
        return 0;
    }

    Lista aux = (*lst)->prox; // Ponteiro auxiliar aponta para o come�o da lista
    Lista aux2; // Ponteiro auxiliar

    while(aux != (*lst)){ // Enquanto ponteiro for != de NULL
    aux2 = aux->prox; //Aponta ao proximo n�
    free(aux);
    aux = aux2;
    }

    // Estamos no ultimo n� (aux == lst)
    (*lst) = NULL;
    free(aux);
    free(aux2);

    return 1;
}


// _______________________________________________________________________________________________________________

/*
Opera��o: apaga_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: endere�o ser v�lido (primeiro endere�o �ponteiro de ponteiro�)
- Processo: liberar a instancia da lista e apagar o seu endere�o
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: instancia da lista liberada.
*/

void apaga_lista(Lista *lst)
{
    Lista aux = *lst;
    while ((*lst)->prox != *lst)//enquanto o pr�ximo elemento n�o for  �ltimo
        {
            (*lst) = (*lst)->prox; //Para percorrer a lista
            free(aux);
            aux = *lst;
        }
        free(*lst);
        lst=NULL;
}
// _______________________________________________________________________________________________________________

/*
Opera��o: get_elem_pos
- Entrada: Endere�o de uma lista, posi��o a obter o elemento.
-  Pr�-Condi��o: Lista existir (Endere�o ser valido), e posi��o ser maior que 0.
- Processo: Atrav�s da posi��o fornecida, busca-se na lista o elemento correspondente aquela posi��o e o retorna atraves da variavel fornecida.
- Sa�da: Retorna a informa��o em char.
- P�s-condi��o: sem p�s condi��o
*/


int get_elem_pos(Lista lst, int pos, char *elem){


    if (lst == NULL){
        return 0;
   } else{
         Lista aux = lst->prox; //Aux aponta para o primeiro n�
         if(pos == 1){
          *elem = aux->info;
         }

         int contador = 1;

         while(contador<pos){
           aux = aux->prox;
           contador++;
         }

         // Aux aponta para o n� desejado
        *elem = aux->info;

    }
}

// _______________________________________________________________________________________________________________

// Opera��es especiais:
// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________

/*
Opera��o: insere_inicio;
- Entrada: Endere�o do endere�o de uma lista e o elemento (char) a ser inserido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um char.
- Processo: Insere (ao inicio) o elemento na lista fornecida.
- Sa�da: 0 (Lista n�o existe), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista.
*/

int insere_inicio(Lista *lst, char elem){

    Lista N = (Lista) malloc(sizeof(struct no)); // Aloca o novo n�

    if (N == NULL) //Falha na aloca��o do n�
    return 0;

    N->info = elem; // Insere o conte�do (valor do elem)

    if (lista_vazia(*lst) == 1){   // Se a lista estiver vazia

        N->prox = N; // Faz o novo n� apontar para ele mesmo
        *lst = N; // Faz a lista apontar para o novo n�, que � o primeiro

    }else{ // Existe ao menos um elemento na lista:

        N->prox = (*lst)->prox; // Faz o novo n� apontar para antigo come�o da lista
        (*lst)->prox = N; // Faz o �ltimo n� apontar para o novo n�
    }
    return 1;
}

/*
Opera��o: insere_posicao;
- Entrada: Endere�o do endere�o de uma lista , a posi��o a inserir e o elemento (char) a ser inserido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido), posi��o menor que o tamanho e elemento ser um char.
- Processo: Insere (na posi��o) o elemento na lista fornecida.
- Sa�da: 0 (Lista n�o existe), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista.
*/
int insere_posicao(Lista *lst,int pos, char elem){


if (lista_vazia(*lst) == 1){   // Se a lista estiver vazia
 return 0; // Quer inserir na posi��o de uma lista vazia
}

int tamanho = 0; //Contador de n�s da lista.
Lista aux = (*lst)->prox; //Faz aux apontar para o 1� n�

 while(aux != (*lst)){ // Enquanto ponteiro for != de NULL
  tamanho++;
  aux = aux->prox;
}
// chegando aqui, o aux t� na ultima posi��o, logo, s� incrementamos mais uma vez.
tamanho++;

// Temos a quantidade de n�s, basta verificar.

if(pos<1 || pos > tamanho){ // Posi��o for menor que 1 e maior que tamanho
  return 0; //Erro!
}
// Lembrando que posi��o 1 = primeiro elemento. Entao posi��o 0 n�o existe!


int contador = 1; //Localizar a posi��o a se inserir na lista;
aux = (*lst)->prox; //Faz aux apontar para o 1� n�

while(contador<pos){    //Enquanto estivermos antes de pos
    aux = aux->prox;
    contador++;
}

// Aux aponta para o local a ser inserido.
aux->info = elem; // Atribuimos ao info o elemento desejado.

return 1; // Sucesso
}


/*

Opera��o: remover_fim;
- Entrada: Endere�o do endere�o de uma lista e uma variavel para receber o valor excluido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um char.
- Processo: Remove o ultimo n�.
- Sa�da: 0 (Lista vazia ou elemento n�o presente na lista), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/

int remover_fim(Lista *lst,char *elem){

 // Se lista estiver vazia:
  if (lista_vazia(*lst) == 1)
  return 0; // Falha


Lista aux = (*lst)->prox; //Faz aux apontar para o 1� n�

  if(*lst == (*lst)->prox){ // Apenas um n�
    elem = aux->info; //Retorna valor do n� a ser removido
    *lst = NULL; //Fazemos a lista apontar pra nada (J� que excluiremos o unico n�)
    free(aux);
    return 1;
  }

  // Existe  +1 n�:

  while(aux->prox != (*lst)){ // Enquanto for diferente da "ultima posi��o"
    aux = aux->prox;
  }

  // Estamos na "penultima" posi��o;
  aux->prox = (*lst)->prox; // Aux aponta pra onde o "ultimo" apontava
  (*lst) = aux;
  aux = aux->prox; //Avan�ando aux pra ultima posi��o.

  free(aux);

  return 1;
}


/*
Opera��o: remove_vogais;
- Entrada: Endere�o do endere�o de uma lista.
- Pr�-Condi��o: Lista existir (Endere�o ser valido).
- Processo: Remove todos os n�s com vogais.
- Sa�da: 0 (Lista vazia), 1 (Elementos removidos com sucesso).
- P�s-condi��o: Os elementos foram removido na lista.
*/


int remove_vogais(Lista *lst){

  // Se lista estiver vazia:
  if (lista_vazia(*lst) == 1)
  return 0; // Falha

  Lista aux = (*lst)->prox; //Faz aux apontar para o 1� n�
  Lista aux2 = NULL; // Aux2


  char letra; //S� pra armazenar temporariamente a letra.

  if(*lst == (*lst)->prox){ // Apenas um n�
    if ( (aux->info == 'A') ||  (aux->info == 'a') ||
         (aux->info == 'E') ||  (aux->info == 'e') ||
         (aux->info == 'I') ||  (aux->info == 'i') ||
         (aux->info == 'O') ||  (aux->info == 'o') ||
         (aux->info == 'U') ||  (aux->info == 'u') ){

          remove_inicio(*lst,&letra); // Sabendo que s� existe um registro, podemos usar a fun��o remove_inicio
         return 1;
         }else{
         return 1; // O char da lista n�o � vogal, logo, n�o precisa ser removido
         }
}


// Existe +1 n�:

while(aux != (*lst)){ // Enquanto for diferente da "ultima posi��o"

 if ( (aux->info == 'A') ||  (aux->info == 'a') ||
         (aux->info == 'E') ||  (aux->info == 'e') ||
         (aux->info == 'I') ||  (aux->info == 'i') ||
         (aux->info == 'O') ||  (aux->info == 'o') ||
         (aux->info == 'U') ||  (aux->info == 'u') ){

    if(aux == (*lst)->prox){ // Se for no primeiro elemento da lista
     remove_inicio(*lst,&letra); // Sabendo que � o primeiro n� podemos usar a fun��o remove_inicio
     aux = aux->prox;
    }

    else{ // N�o for a primeira posi��o

    aux2 = (*lst)->prox; // aux2 aponta ao inicio

    while(aux2->prox != aux || aux2 != aux){ // Percorre at� achar a posi��o a ser removida
        aux2 = aux2->prox;
    }

    aux2->prox = aux->prox; // aux2 aponta pra onde aux apontava
    free(aux); //Exclui o n�
    aux = aux->prox;

    }

 }else{ // Se aux n�o for vogal
     aux = aux->prox;
 }

}
// Estamos na "ultima" posi��o;
if ( (aux->info == 'A') ||  (aux->info == 'a') ||
         (aux->info == 'E') ||  (aux->info == 'e') ||
         (aux->info == 'I') ||  (aux->info == 'i') ||
         (aux->info == 'O') ||  (aux->info == 'o') ||
         (aux->info == 'U') ||  (aux->info == 'u') ){

         remover_fim(*lst,&letra); // Sabendo que � o ultimo n�, podemos usar a fun��o

         }
         // Caso ultimo n� n�o seja vogal, n�o mexemos nele.
         return 1;

}
// _______________________________________________________________________________________________________________

/*
Opera��o: libera
- Entrada: Endere�o de uma lista
- Pr�-Condi��o: Lista existir (Endere�o ser valido)
- Processo: Retira a aloca��o (Libera) de uma determinada lista.
- Sa�da: Sem saida (VOID).
- P�s-condi��o: A lista foi �liberada� da memoria.
*/

void libera(Lista x){

    if(x != NULL){
        free(x);
        x = NULL;
    }
}

// _______________________________________________________________________________________________________________

int tamanho_lista(Lista *lst, int *tam){
if (lista_vazia(*lst) == 1){   // Se a lista estiver vazia
 tam = 0;
 return 0; // Quer inserir na posi��o de uma lista vazia
}
int tamanho = 0; //Contador de n�s da lista.
Lista aux = (*lst)->prox; //Faz aux apontar para o 1� n�


while(aux != (*lst)){ // Enquanto ponteiro for != de NULL
  tamanho++;
  aux = aux->prox;
}
// chegando aqui, o aux t� na ultima posi��o, logo, s� incrementamos mais uma vez.
tamanho++;

tam = tamanho;
return 1;
}

