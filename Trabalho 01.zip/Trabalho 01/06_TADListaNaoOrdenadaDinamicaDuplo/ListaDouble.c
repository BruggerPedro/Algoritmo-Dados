#include <stddef.h>
#include <stdlib.h>
#include "ListaDouble.h"


struct no{
    double info; // Elemento a ser inserido
    struct no *ant; // Por ser dinamico, agora temos um ponteiro que "aponta" ao n� anterior
    struct no *prox; // Por ser dinamico, agora temos um ponteiro que "aponta" ao proximo n�
};

//_______________________________________________________________________________________________________________

/*
Opera��o: cria_lista
- Entrada: Sem entrada.
  Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Cria uma lista e retorna o endere�o de uma lista apontando pra NULL.
- Sa�da: NULL
- P�s-condi��o: Sem p�s-condi��o.
*/

Lista cria_lista(){
    return NULL;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: lista_vazia;
- Entrada: Endere�o de uma lista.
- Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Verifica se a lista est� vazia.
- Sa�da: 0 (Lista n�o est� vazia), 1 (Lista vazia)
- P�s-condi��o: Sem p�s-condi��o.
*/


int lista_vazia (Lista lst) {
       if (lst == NULL)
        return 1;
       else
        return 0;
}
// _______________________________________________________________________________________________________________

/* Na teoria, n�o existe como "encher" uma lista dinamica, [exceto pela limita��o de espa�o na memoria])*/


//int lista_cheia(Lista *li){
//return 0;
//}
// _______________________________________________________________________________________________________________

// _______________________________________________________________________________________________________________

/*
Opera��o: insere_elem;
- Entrada: Endere�o do endere�o de uma lista e o elemento (double) a ser inserido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um double.
- Processo: Insere (de forma n�o ordenada) o elemento na lista fornecida.
- Sa�da: 0 (Lista n�o existe), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista de forma n�o ordenada.
*/

int insere_elemento(Lista *lst, double elem)
{
    // Aloca um novo n� e preenche campo info
    Lista N = (Lista) malloc(sizeof(struct no));
    if (N == NULL)
        { return 0; }
    // Falha: n� n�o alocado
    N->info = elem; // Insere o conte�do (valor do elem)
    N->ant = NULL; // N�o tem antecessor do novo n�
    N->prox = *lst; // Sucessor do novo n� recebe mesmo end. da lista
    if (lista_vazia(*lst) == 0) // Se lista N�O vazia
    (*lst)->ant = N; // Faz o antecessor do 1o n� ser o novo n�
    *lst = N; // Faz a lista apontar para o novo n�
    return 1;
}

/*
Opera��o: remove_elem;
- Entrada: Endere�o do endere�o de uma lista e o elemento (double) a ser removido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um double.
- Processo: Remove o elemento na lista fornecida.
- Sa�da: 0 (Lista vazia ou elemento n�o presente na lista), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/
int remove_elemento(Lista *lst, double elem)
{
    if (lista_vazia(*lst)==1) // Trata lista vazia
            return 0;
    Lista aux = *lst; // Faz aux apontar para 1o n�
    while (aux->prox != NULL && aux->info != elem)
            aux = aux->prox;
    if (aux->info != elem)
        return 0; // Elemento n�o est� na lista

    if (aux->prox != NULL) // Se o proximo elemento existir
        (aux)->prox->ant = aux->ant;  // ant do proximo recebe o ant do aux

    if (aux->ant != NULL) // Se o elemento anterior existir
        (aux)->ant->prox = aux->prox; // proximo do anterior recebe o prox do aux

    if (aux == *lst) *lst = aux->prox;
    free(aux);
    return 1;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: apaga_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: endere�o ser v�lido (primeiro endere�o �ponteiro de ponteiro�)
- Processo: liberar a instancia da lista e apagar o seu endere�o
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: instancia da lista liberada.
*/

void apaga_lista(Lista *lst)
{
    Lista aux = *lst;
    while ((*lst)->prox != NULL)//ENQUANTO o pr�ximo elemento n�o for  �ltimo
        {
            (*lst) = (*lst)->prox; //Percorre a lista
            free(aux);//Aumenta o contador
            aux = *lst;
        }
        free(*lst);
        lst=NULL;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: esvazia_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: Lista existir (Endere�o ser valido)
- Processo: Esvaziar a lista.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: a instancia da lista no estado de vazia
*/

int esvazia_lista(Lista *lst){

    if(lst == NULL) { // Se o ponteiro estiver apontando NULL, a lista est� vazia
      return 0;
      }

    Lista aux = *lst; //Ponteiro auxiliar aponta para o come�o da lista
    Lista aux2 = NULL;


    if( ((*lst)->prox == NULL) && (*lst)->ant == NULL){ // Verifica se � n� unico
      (*lst) = NULL;
      free(aux);
      return 1; // Sucesso
    }

    while(aux->prox != NULL){
    aux2 = aux->prox;
    free(aux);
    aux = aux2;
    }

    // Aux est� no ultimo n�
    (*lst) = NULL;
      free(aux);

    return 1; // Sucesso

}

// _______________________________________________________________________________________________________________

/*
Opera��o: get_elem_pos
- Entrada: Endere�o de uma lista, posi��o a obter o elemento e uma variavel para receber a informa��o da dita posi��o.
-  Pr�-Condi��o: Lista existir (Endere�o ser valido), a lista n�o estar vazia e posi��o ser maior que 0.
- Processo: Atrav�s da posi��o fornecida, busca-se na lista o elemento correspondente aquela posi��o e o retorna atraves da variavel fornecida.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: A variavel recebe o valor do elemento presente na posi��o fornecida.
*/

int get_elem_pos(Lista lst, int pos)
{
    if (lst == NULL)
        return 0;
    else
    {
        Lista aux = lst;
        for(int i = 1; i<pos; i++)
            {
                if(aux->prox != NULL)
                    aux=aux->prox;
                else
                    return 0;
            }
        return aux->info;
    }
}


// _______________________________________________________________________________________________________________

// Opera��es especiais:
// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________



// _______________________________________________________________________________________________________________


/*
Opera��o: remove_todos;
- Entrada: Endere�o do endere�o de uma lista e o elemento (double) a ser removido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um double.
- Processo: Remove todas as ocorrencias do elemento na lista.
- Sa�da: 0 (Lista vazia), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/

int remove_todos(Lista *lst, double *elem){

if(lst == NULL) { // Se o ponteiro estiver apontando NULL, a lista est� vazia
      return 0;
}


Lista aux = *lst;

// N� unico
if( ((*lst)->prox == NULL) && (*lst)->ant == NULL){ // Verifica se � n� unico

if(aux->info == *elem){ // Elemento passado � exatamente o presente no n�
  remove_elemento(&lst,*elem);
}else{ // Se o elemento for diferente
 return 1;
}
}

do{

  if(aux->info != *elem){ // Verifica��o, se a info do aux � diferente
  aux = aux->prox; //Movimentar o aux
}

// Achou um n� com o elemento
remove_elemento(&lst,*elem);
aux = aux->prox;

}while (aux->prox != NULL); // Repete at� entrar no ultimo n�

// Ultimo n�
if(aux->info == *elem){ // Elemento passado � exatamente o presente no n�
   remove_elemento(&lst,*elem);
   return 1;
}else{ // Se o elemento for diferente
 return 1;
}
}
// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________


/*
Opera��o: remove_todos;
- Entrada: Endere�o do endere�o de uma lista e o elemento (double) a ser removido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido) e elemento ser um double.
- Processo: Remove o maior elemento da lista.
- Sa�da: 0 (Lista vazia), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/


int remove_maior(Lista *lst, double *elem){

    if(lst == NULL || lista_vazia(*lst)== 1){
        return 0;
    }

    Lista maior = NULL;

    if ((*lst)->prox == NULL) // Verifica se existe apenas um n�
    {
        free(*lst);
        return 1;
    }

    // +1 no

    maior = *lst;
    Lista aux = (*lst)->prox; //aux est� a frente do ponteiro "maior"


    while (aux->prox != NULL)
    {
        if(aux->info>maior->info)
            maior = aux;
        aux=aux->prox;
    }

    if(aux->info > maior->info)
            maior = aux;
    if (maior->prox != NULL)
        (maior)->prox->ant = maior->ant;
    if (maior->ant != NULL)
        (maior)->ant->prox = maior->prox;
    if (maior == *lst) *lst = maior->prox;

    // Chegando aqui, temos o maior no (Ponteiro maior)
    *elem = maior->info;

    free(maior);
    return 1;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: insere_posicao;
- Entrada: Endere�o do endere�o de uma lista, a posicao, e o elemento (double) a ser inserido.
- Pr�-Condi��o: Lista existir (Endere�o ser valido), ter a posi��o na lista  e elemento ser um float.
- Processo: Insere na posi��o fornecida o elemento na lista.
- Sa�da: 0 (Lista n�o existe ou lista vazia), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista na posi��o fornecida.
*/

int insere_posicao(Lista *lst, int pos, double elem){

    if(lst == NULL){
    return 0;
    }

   // Inserir na lista vazia
    if (lista_vazia(*lst) == 1){   // Se a lista estiver vazia
    return 0; // Quer inserir na posi��o de uma lista vazia
    }

   Lista aux = *lst;

   // Inserir na lista com apenas 1 n�
   if(aux->prox == NULL && aux->ant == NULL){
    if(pos == 1){
           insere_elemento(*lst,elem);
        }else{
         return 0; // Falha
        }
   }

   int tam = 1; // Recebe a quantidade de n�s da lista

   while(aux->prox != NULL){
    tam++;
   }
   //Temos a quantidade de n�s da lista

   if(pos > tam){
    return 0; //Quer inserir em uma posi��o que nao existe
   }

   int cont = 1;
   aux = aux->prox;

   while(cont<pos){
    cont++;
    aux = aux->prox;
   }

   // Aux aponta para o n� a ser "Substituido"
   aux->info = elem;
   return 1;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: inverte;
- Entrada: Endere�o do endere�o de uma lista.
- Pr�-Condi��o: Lista existir (Endere�o ser valido).
- Processo: Recebe uma lista L e retorna uma nova lista L2, formada pelos elementos de L na
ordem inversa.
- Sa�da:  NULL(Caso a listas fornecida n�o existe) ou ponteiro que referencia o local onde foi criada a lista.
- P�s-condi��o: Sem p�s-condi��o.
*/

Lista inverte(Lista* lst){
    if(lst == NULL || lista_vazia(*lst)== 1){
        return NULL;
    }

    Lista *l2;
     Lista aux = *lst;
         // Se tiver um n�
    if(aux->prox == NULL && aux->ant == NULL){ //Verifica��o se possui apenas um n�
    insere_elemento(*l2,aux->info);
    return l2;
    }

    // Temos +1 n�


    while(aux->prox != NULL){
        insere_elemento(*l2,aux->info);
        aux = aux->prox;
    }

    // Aux est� na ultima posi��o
    insere_elemento(*l2,aux->info);
    return l2;

}

// _______________________________________________________________________________________________________________

/*
Opera��o: libera
- Entrada: Endere�o de uma lista
- Pr�-Condi��o: Lista existir (Endere�o ser valido)
- Processo: Retira a aloca��o (Libera) de uma determinada lista.
- Sa�da: Sem saida (VOID).
- P�s-condi��o: A lista foi �liberada� da memoria.
*/

void libera(Lista x){

    if(x != NULL){
        free(x);
        x = NULL;
    }
}

// _______________________________________________________________________________________________________________
// _______________________________________________________________________________________________________________

int tamanho_lista(Lista *lst, int *tam){
if (lista_vazia(*lst) == 1){   // Se a lista estiver vazia
 tam = 0;
 return 0; // Quer inserir na posi��o de uma lista vazia
}
int tamanho = 0; //Contador de n�s da lista.
Lista aux = (*lst)->prox; //Faz aux apontar para o 1� n�


while(aux != (*lst)){ // Enquanto ponteiro for != de NULL
  tamanho++;
  aux = aux->prox;
}
// chegando aqui, o aux t� na ultima posi��o, logo, s� incrementamos mais uma vez.
tamanho++;

tam = tamanho;
return 1;
}
