#include <stddef.h>
#include <stdlib.h>
#include "ListaOrdenadaCab.h"

struct no{
int info; //N�mero
struct no * prox; // Por ser dinamico, agora temos um ponteiro que "aponta" ao proximo n�
};

//_______________________________________________________________________________________________________________

/*
Opera��o: cria_lista
- Entrada: Sem entrada.
  Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Cria uma lista e retorna o endere�o de uma lista com a cabe�a(HEAD) criado.
- Sa�da: Ponteiro que referencia o local onde foi criada a lista(Podendo ser NULL quando mal-alocado).
- P�s-condi��o: Sem p�s-condi��o.
*/

Lista cria_lista(){
    Lista cab;
    cab = (Lista) malloc(sizeof(struct no));

    if(cab != NULL){ // Se a aloca��o funcionou:
     cab->prox = NULL; // "cabe�a aponta pra NULL"
     cab->info = 0; //Vamos guardar o tamanho da lista
    }
    return cab; // Retorno j� com a cabe�a
}

//_______________________________________________________________________________________________________________

/*
Opera��o: lista_vazia;
- Entrada: Endere�o de uma lista.
- Pr�-Condi��o: Sem pr�-condi��es.
- Processo: Verifica se a lista est� vazia.
- Sa�da: 0 (Lista n�o est� vazia), 1 (Lista vazia)
- P�s-condi��o: Sem p�s-condi��o.
*/

int lista_vazia(Lista lst){
    if(lst->prox == NULL)
        return 1; //Lista vazia
    else
        return 0; //Lista aponta pra algo, logo, n�o � vazia
}

// _______________________________________________________________________________________________________________

/* Na teoria, n�o existe como "encher" uma lista dinamica, [exceto pela limita��o de espa�o na memoria])*/


//int lista_cheia(Lista *li){
//return 0;
//}
// _______________________________________________________________________________________________________________

/*
Opera��o: insere_ord;
- Entrada: Endere�o do endere�o de uma lista e o elemento (inteiro) a ser inserido.
- Pr�-Condi��o: Elemento ser um inteiro.
- Processo: Insere (de forma ordenada) o elemento na lista fornecida.
- Sa�da: 0 (Lista n�o existe), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista de forma ordenada.
*/

int insere_ord(Lista *lst, int elem){
    // Aloca um novo n�
    Lista N = (Lista) malloc(sizeof(struct no)); // N aloca um novo campo de lista

    if (N == NULL){ return 0;} //Falha: N�o conseguiu alocar o N�

    N->info = elem; //Insere o conteudo (valor de elem)



    // Percorrimento da lista (elem > 1� n� da lista)

    Lista aux = *lst; //Faz aux apontar para 1� n�

    while(aux->prox != NULL && aux->prox->info < elem) // Se existir proximo E Info proximo for menor que o elemento
     aux = aux->prox; //Avan�a

    // Insere o novo elemento na lista
    N->prox = aux->prox; // Prox do N receber� o prox de Aux
    aux->prox = N; //Prox de aux agora aponta pra N
    (*lst)->info++; //Utiliza o info do cabe�alho pra contador e o incrementa
    return 1; //Sucesso
}
// _______________________________________________________________________________________________________________

/*
Opera��o: remove_ord;
- Entrada: Endere�o do endere�o de uma lista e o elemento (inteiro) a ser removido.
- Pr�-Condi��o: Lista existir (existir n� al�m do HEAD) e elemento ser um inteiro.
- Processo: Remove o elemento na lista fornecida e mant�m ordenada.
- Sa�da: 0 (Lista vazia ou elemento n�o presente na lista), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/

int remove_ord(Lista *lst, int elem){
    if(lista_vazia(*lst) == 1) // Se lista for vazia
    return 0; //falha

    Lista aux = *lst; //Ponteiro auxiliar para o 1�  n�


    // Percorrimento at� final de lista, achar elem ou n� maior
    while(aux->prox != NULL && aux->prox->info < elem) // Enquanto existir proximo E info do proximo for menor que elem
   aux = aux->prox;

    if (aux->prox == NULL || aux->prox->info > elem) // Se n�o existir proximo OU info do prox for MAIOR que elem
        return 0; //Falha

    // Remove elemento da lista
    Lista aux2 = aux->prox; //Aponta n� a ser removido
    aux->prox = aux2->prox; //Retira n� da lista
    free(aux2); //Libera mem�ria alocada
    (*lst)->info--; // Decrementar a quantidade de n�s.
    return 1;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: esvazia_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: Lista existir (existir n� al�m do HEAD).
- Processo: Esvaziar a lista.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: a instancia da lista no estado de vazia
*/

int esvazia_lista(Lista *lst){

    if((*lst)->prox == NULL) { // Se o ponteiro estiver apontando NULL, a lista est� vazia
      return 0;
      }

    Lista aux = (*lst)->prox; //Ponteiro auxiliar aponta para o come�o da lista

    while((*lst)->prox != NULL){ //Enquanto ponteiro for != de NULL
         (*lst)->prox = aux->prox; //lst recebe o que aux apontava
          free(aux);  //Libera o n� atual
          aux = (*lst)->prox; // aux aponta pra n� atual
    }
    free(aux); //Nessa regi�o, lst aponta pra null, ent�o, vamos liberar o aux
    (*lst)->prox = NULL; // Aponta pra nada.

    return 1; // Sucesso

}

// _______________________________________________________________________________________________________________

/*
Opera��o: apaga_lista
- Entrada: Endere�o do endere�o de uma lista
- Pr�-Condi��o: Lista existir (existir n� al�m do HEAD).
- Processo: liberar a instancia da lista e apagar o seu endere�o
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: instancia da lista liberada.
*/
void apaga_lista(Lista *lst){

    if((*lst)->prox != NULL){ //Se for igual a null, a lista j� est� excluida

        Lista aux =(*lst)->prox; // Aux aponta pra inicio da lista

        while((*lst)->prox != NULL){ //Enquanto ponteiro for != de NULL
         (*lst)->prox = aux->prox; //lst recebe o que aux apontava
          free(aux);  //Libera o n� atual
        aux = (*lst)->prox; // aux aponta pra n� atual
    }
        free(aux); // Liberamos o aux
        free(lst); // Liberamos o lst
        //OBS: A diferen�a entre apaga e esvazia est� na linha acima.
        // Enquanto no esvazia "liberamos" apenas o aux, no apaga,
        // liberamos tambem o lst (responsavel por apontar a primeira posi��o na lista)
    }
}
// _______________________________________________________________________________________________________________

/*
Opera��o: get_elem_pos
- Entrada: Endere�o de uma lista, posi��o a obter o elemento e uma variavel para receber a informa��o da dita posi��o.
-  Pr�-Condi��o: Lista existir (existir n� al�m do HEAD), a lista n�o estar vazia e posi��o ser maior que 0.
- Processo: Atrav�s da posi��o fornecida, busca-se na lista o elemento correspondente aquela posi��o e o retorna atraves da variavel fornecida.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: A variavel recebe o valor do elemento presente na posi��o fornecida.
*/

int get_elem_pos(Lista *lst, int pos, float *elem){
    // pos < 1 porque a pos=0 Seria o head
    if((*lst)->prox == NULL || lista_vazia(*lst) || pos < 1)
        // lst aponta pra null? OU lista � vazia? OU pos <0
     return 0; // FALHA
    Lista aux = (*lst)->prox;
    *elem = aux->info; // elem recebe aquela informa��o do n� atual
    return 1; //Sucesso
}

// _______________________________________________________________________________________________________________

// Opera��es especiais:
// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________


// _______________________________________________________________________________________________________________

/*
Opera��o: tamanho_lista
- Entrada: Endere�o do endere�o de uma lista e uma variavel para receber o tamanho da lista.
- Pr�-Condi��o: Lista existir (existir n� al�m do HEAD).
- Processo: Percorre toda a lista e contabiliza o tamanho da mesma.
- Sa�da: 1 (sucesso) ou 0 (falha)
- P�s-condi��o: A lista foi contabilizada e seu tamanho foi atribuido para a variavel vinda de argumento.*/


int tamanho_lista(Lista *lst, int *tam){

    if((*lst)->prox == NULL) {// Se o ponteiro estiver apontando NULL, a lista est� vazia
      return 0;
        }

    int contador = 0; // Variavel contadora

    if(lista_vazia(*lst) == 1){ // Se lista estiver vazia
        *tam = contador; //Basta atribuir ao tam o valor que est� em contador(0)
        return 1;
    }


    Lista aux = *lst; // Aux aponta pra inicio da lista

    while(aux->prox != NULL){ // Enquanto "existir" proximo
        contador++;
        aux = aux->prox;
    }

    *tam = contador ; //Como o aux verifica uma posi��o "a frente" do n�, somamos o contador com +1 (N� atual que n�o possui prox n�)

    return 1;

}
// _______________________________________________________________________________________________________________

/*
Opera��o: remove_elem;
- Entrada: Endere�o do endere�o de uma lista, a pos��o a ser excluida e uma variavel pra receber o valor excluido.
- Pr�-Condi��o: Lista existir (existir n� al�m do HEAD) e posi��o existir na lista.
- Processo: Remove o elemento presente na posi��o fornecida e oferece o valor presente no mesmo.
- Sa�da: 0 (Lista vazia ou posi��o n�o presente na lista), 1 (Elemento removido com sucesso).
- P�s-condi��o: O elemento foi removido na lista.
*/



int remove_pos(Lista *lst, int pos, int *valor)
{
    if((*lst)->prox == NULL)   // Se o ponteiro->prox estiver null, a lista t� vazia
        return 0;


if(pos == 0) // Se quiser remover a primeira posi��o, basta usar a fun��o criada
 {
 int n = ((*lst)->prox)->info;
 remove_ord(lst,n);
 (*valor) = n;
 return 1;
}

int tam;
tamanho_lista(lst,&tam);
// 2 > 2
if(pos > tam-1){ // Se o usuario quiser uma posi��o que n�o existe(lembrando que o primeiro no � pos=0)
    return 0;
}

int contador = 1; //Come�a com 1 pq 0 ser� a cabe�a
Lista aux = (*lst)->prox; //aux aponta pra inicio da lista
aux = aux -> prox; // Se n�o queremos a primeira posi��o, vamos avan�ar

while(aux->prox != NULL || contador < pos){
    contador++;
    aux = aux->prox;
}

if(contador == pos){
   int n = aux->info;
   remove_ord(lst,n);
   (*valor) = n;

}
return 1;
}

// _______________________________________________________________________________________________________________

/*
Opera��o: inverter_lista
- Entrada: Endere�o do endere�o da lista a ser sua inversa.
- Pr�-Condi��o: Lista existir (existir n� al�m do HEAD).
- Processo: Recebe uma lista L e retorna uma nova lista L2, formada pelos elementos de L na
ordem inversa.
- Sa�da: NULL(Caso a lista fornecidas n�o existe) ou ponteiro que referencia o local onde foi criada a lista.
- P�s-condi��o: Sem p�s-condi��o.*/

Lista inverter_lista(Lista *l1){
        if((*l1)->prox == NULL )   // Se o ponteiro->prox estiver null, a lista t� vazia
        return NULL;

Lista l2 = cria_lista(); // Cria a l2 (lista inversa)

Lista aux = (*l1)->prox; // Aux Lista 1

int tam;
tamanho_lista(l1,&tam);

int i;

for(i=0;i<tam;i++){   // I percorre o tamanho da lista 1

insere_ord(&l2, aux->info);    // Pede para inserir
aux = aux->prox;
}
free(aux);

return l2;

}

// _______________________________________________________________________________________________________________

/*
Opera��o: intercala_listas
- Entrada: Endere�o do endere�o de duas listas a serem intercaladas.
- Pr�-Condi��o: Listas existirem (existir n� al�m do HEAD).
- Processo: Recebe duas listas e retorna uma terceira, formada pelos elementos das duas listas intercalados (Sem altera��o nas duas listas).
- Sa�da: NULL(Caso alguma das listas fornecidas n�o existe) ou ponteiro que referencia o local onde foi criada a terceira lista.
- P�s-condi��o: Sem p�s-condi��o.*/

Lista intercala(Lista *l1,Lista *l2){
    if((*l1)->prox == NULL || (*l2)->prox == NULL)   // Se o ponteiro->prox estiver null, a lista t� vazia
    return NULL;

    Lista l3 = cria_lista(); // Cria a terceira lista

    Lista aux = (*l1)->prox;

    int tam1, tam2,tamt;

    tamanho_lista(l1,&tam1);
    tamanho_lista(l2,&tam2);

    tamt = tam1+tam2;

    int i;

    for(i=0;i<tam1;i++){   // I percorre o tamanho da lista 1
    insere_ord(&l3, aux->info);    // Pede para inserir
    aux = aux->prox;
    }

    aux = (*l2)->prox; // Aux agora � pra lista 2

    for(i=tam1;i<tamt;i++){
    insere_ord(&l3, aux->info);    // Pede para inserir
    aux = aux->prox;
    }

    free(aux);

return l3;

}

// _______________________________________________________________________________________________________________

/*
Opera��o: libera
- Entrada: Endere�o de uma lista
- Pr�-Condi��o: Lista existir (Endere�o ser valido)
- Processo: Retira a aloca��o (Libera) de uma determinada lista.
- Sa�da: Sem saida (VOID).
- P�s-condi��o: A lista foi �liberada� da memoria.
*/

void libera(Lista x){

    if(x != NULL){
        free(x);
        x = NULL;
    }
}
// _______________________________________________________________________________________________________________


// Fun��o insere_elem [EXTRA] N�o definida no .h por ser "escondida" do aplicativo:

// _______________________________________________________________________________________________________________
/*
Opera��o: insere_elem;
- Entrada: Endere�o do endere�o de uma lista e o elemento (inteiro) a ser inserido.
- Pr�-Condi��o: Elemento ser um inteiro.
- Processo: Insere (de forma n�o ordenada) o elemento na lista fornecida.
- Sa�da: 0 (Lista n�o existe), 1 (Elemento inserido com sucesso).
- P�s-condi��o: O elemento foi inserido na lista de forma n�o ordenada.
*/

int insere_elem(Lista *lst, int elem)
{

 // Aloca um novo n�
 Lista N = (Lista) malloc(sizeof(struct no));

 if(N==NULL) //Falha, aloca��o mal-sucedida
    {
        return 0;
    }

 //Preenche os campos do novo n�

 N->info = elem;
 N->prox = (*lst)->prox;
 (*lst)->prox = N;
 (*lst)->info++; // Contador de n�s

 return 1;
}

// _______________________________________________________________________________________________________________
